// Создаём HTML загрузочного экрана
function createLoadingScreen() {
  return $(`
    <div class="my-loading-screen">
      <div class="my-loading-spinner">${game.i18n.localize("LOADING.SPINNER")}</div>
      <h2>${game.i18n.localize("LOADING.TITLE")}</h2>
      <p>${game.i18n.format("LOADING.MESSAGE", { progress: 0 })}</p>
      <small>${game.i18n.localize("LOADING.TIP")}</small>
    </div>
  `);
}

// Показываем экран при начале загрузки
Hooks.on("preCreateScene", () => {
  $("body").append(createLoadingScreen());
});

// Обновляем прогресс
Hooks.on("canvasLoading", (progress) => {
  const message = game.i18n.format("LOADING.MESSAGE", { progress: Math.round(progress) });
  $(".my-loading-screen p").html(message);
});

// Скрываем после загрузки
Hooks.on("canvasReady", () => {
  $(".my-loading-screen").fadeOut(500, function() { $(this).remove(); });
});